﻿using System;
using System.Data;


namespace ODB_3
{
    

    class Program
    {
        static void FillDataSet(DataSet ds)
        {
            DataColumn carIDColumn = new DataColumn("CarID", typeof(int));
            carIDColumn.Caption = "Car ID";
            carIDColumn.ReadOnly = true;
            carIDColumn.AllowDBNull = false;
            carIDColumn.Unique = true;
            carIDColumn.AutoIncrementSeed = 0;
            carIDColumn.AutoIncrementStep = 1;
            DataColumn carMakeColumn = new DataColumn("Make", typeof(string));
            DataColumn carColorColumn = new DataColumn("Color", typeof(string));
            DataColumn carPetName = new DataColumn("PetName", typeof(string));
            carPetName.Caption = "Дружественное имя";
            DataTable inventoryTable = new DataTable("Inventory");
            inventoryTable.Columns.AddRange(new DataColumn[]
                 { carIDColumn, carMakeColumn, carColorColumn, carPetName });

            DataRow carRow = inventoryTable.NewRow();
            carRow["CarID"] = 1;
            carRow["Make"] = "BMW";
            carRow["Color"] = "Black";
            carRow["PetName"] = "Hamlet";
            inventoryTable.Rows.Add(carRow);

            carRow = inventoryTable.NewRow();
            carRow[0] = 2;
            carRow[1] = "Saab";
            carRow[2] = "Red";
            carRow[3] = "Sea Breeze";
            inventoryTable.Rows.Add(carRow);
            inventoryTable.PrimaryKey = new DataColumn[] { inventoryTable.Columns[0] };
            // Добавление таблицы в DataSet
            ds.Tables.Add(inventoryTable);

        }
        static void Main(string[] args)
        {
          
            // Создание DataSet
            DataSet carsInventoryDS = new DataSet("Car Inventory");
            carsInventoryDS.ExtendedProperties["TimeStamp"] = DateTime.Now;
            carsInventoryDS.ExtendedProperties["DataSetID"] = Guid.NewGuid();
            carsInventoryDS.ExtendedProperties["Company"] = "Мой магазин";
            FillDataSet(carsInventoryDS);
            PrintDataSet(carsInventoryDS);

            Console.ReadLine();

        }
        static void PrintTable(DataTable dt)
        {
            // Создание объекта DataTableReader
            DataTableReader dtReader = dt.CreateDataReader();

            while (dtReader.Read())
            {
                for (int i = 0; i < dtReader.FieldCount; i++)
                    Console.Write("{0}\t", dtReader.GetValue(i).ToString().Trim());
                Console.WriteLine();
            }
            dtReader.Close();
        }
        static void PrintDataSet(DataSet ds)
        {
            // Вывод имени и расширенных свойств
            Console.WriteLine("*** Объекты DataSet ***\n");
            Console.WriteLine("Имя DataSet: {0}", ds.DataSetName);
            foreach (System.Collections.DictionaryEntry de in ds.ExtendedProperties)
                Console.WriteLine("Ключ = {0}, Значение = {1}", de.Key, de.Value);
            Console.WriteLine();

            // Вывод каждой таблицы
            foreach (DataTable dt in ds.Tables)
            {
                Console.WriteLine("=> Таблица: {0}", dt.TableName);

                // Вывод имени столбцов
                for (int curCol = 0; curCol < dt.Columns.Count; curCol++)
                    Console.Write(dt.Columns[curCol].ColumnName + "\t");
                Console.WriteLine("\n--------------------------");

                // Выводим содержимое таблицы
                PrintTable(dt);
            }
        }
    }
}
