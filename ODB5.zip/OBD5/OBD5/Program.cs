﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace OBD5
{
    /*public class Driver
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public int Spent_Days { get; set; }
        public bool Is_free { get; set; }
        //public List<User> Users { get; set; } = new List<User>();
    }

    public class Truck
    {
        public string Id { get; set; }
        public bool Is_free { get; set; }
        //public List<User> Users { get; set; } = new List<User>();
    }

    public class Crew
    {
        public int Id { get; set; }
        public string TruckId { get; set; }
        public Truck Truck { get; set; }
        public long Dr1_Id { get; set; }
        public Driver Dr1 { get; set; }
        public long Dr2_Id { get; set; }
        public Driver Dr2 { get; set; }
    }


    public class ApplicationContext : DbContext
    {
        public DbSet<Driver> Drivers { get; set; }
        public DbSet<Truck> Trucks { get; set; }

        public DbSet<Crew> Crews { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=helloappdb;Trusted_Connection=True;");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }*/
    public class Model
    {
        public string Name { get; set; }
        public string Company { get; set; }
        public int Price { get; set; }
    }
    public class Country
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class Company
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CountryId { get; set; }
        public Country Country { get; set; }
    }
    public class Phone
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }

        public int CompanyId { get; set; }
        public Company Company { get; set; }
    }
    class PhoneContext : DbContext
    {
        static PhoneContext()
        {
            Database.SetInitializer<PhoneContext>(new MyContextInitializer());
        }
        public PhoneContext() : base("DefaultConnection")
        {
        }

        public DbSet<Company> Companies { get; set; }
        public DbSet<Phone> Phones { get; set; }

        public DbSet<Country> Countries { get; set; }
    }

    class MyContextInitializer : DropCreateDatabaseAlways<PhoneContext>
    {
        protected override void Seed(PhoneContext db)
        {
            Country C1 = new Country { Id = 1, Name = "Korea" };
            Country C2 = new Country { Id = 2, Name = "Taiwan" };
            db.Countries.Add(C1);
            db.Countries.Add(C2);
            db.SaveChanges();

            Company c1 = new Company { Name = "Samsung", Country = C1 };
            Company c2 = new Company { Name = "Apple", Country = C2 };
            db.Companies.Add(c1);
            db.Companies.Add(c2);

            db.SaveChanges();

            Phone p1 = new Phone { Name = "Samsung Galaxy S5", Price = 20000, Company = c1 };
            Phone p2 = new Phone { Name = "Samsung Galaxy S4", Price = 15000, Company = c1 };
            Phone p3 = new Phone { Name = "iPhone5", Price = 28000, Company = c2 };
            Phone p4 = new Phone { Name = "iPhone 4S", Price = 23000, Company = c2 };

            db.Phones.AddRange(new List<Phone>() { p1, p2, p3, p4 });
            db.SaveChanges();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n1.1 View table");
            using (PhoneContext db = new PhoneContext())
            {
                var phones = from p in db.Phones
                             where p.CompanyId == 1
                             select p;
                foreach (Phone p in phones)
                    Console.WriteLine("{0}.{1} - {2}", p.Id, p.Name, p.Price);
            }
            //Console.ReadKey();

            Console.WriteLine("\n1.2 View table");
            using (PhoneContext db = new PhoneContext())
            {
                var phones = db.Phones.Where(p => p.CompanyId == 1);
                foreach (Phone p in phones)
                    Console.WriteLine("{0}.{1} - {2}", p.Id, p.Name, p.Price);
            }
            //Console.ReadKey();

            Console.WriteLine("\n1.3 View table");
            using (PhoneContext db = new PhoneContext())
            {
                Phone myphone = db.Phones.FirstOrDefault(p => p.Id == 3);
                if (myphone != null)
                    Console.WriteLine(myphone.Name);
            }
            //Console.ReadKey();

            Console.WriteLine("\n1.4 View table");
            using (PhoneContext db = new PhoneContext())
            {
                var phones = db.Phones.Select(p => new Model
                {
                    Name = p.Name,
                    Price = p.Price,
                    Company = p.Company.Name
                });
                foreach (Model p in phones)
                    Console.WriteLine("{0} ({1}) - {2}", p.Name, p.Company, p.Price);
            }
            Console.ReadKey();

            Console.WriteLine("\n2.1 Sort");
            using (PhoneContext db = new PhoneContext())
            {
                var phones = db.Phones.OrderBy(p => p.Name);
                foreach (Phone p in phones)
                    Console.WriteLine("{0}.{1} - {2}", p.Id, p.Name, p.Price);
            }
            //Console.ReadKey();


            Console.WriteLine("\n2.2 Sort");
            using (PhoneContext db = new PhoneContext())
            {
                var phones = db.Phones
                .Select(p => new { Name = p.Name, Company = p.Company.Name, Price = p.Price })
                .OrderByDescending(p => p.Price)
                .ThenBy(p => p.Company);
                foreach (var p in phones)
                    Console.WriteLine("{0}.{1} - {2}", p.Name, p.Company, p.Price);
            }
            Console.ReadKey();

            Console.WriteLine("\n3.1 Join");
            using (PhoneContext db = new PhoneContext())
            {
                var phones = db.Phones.Join(db.Companies, // второй набор
                    p => p.CompanyId, // свойство-селектор объекта из первого набора
                    c => c.Id, // свойство-селектор объекта из второго набора
                    (p, c) => new // результат
                    {
                        Name = p.Name,
                        Company = c.Name,
                        Price = p.Price
                    });
                foreach (var p in phones)
                    Console.WriteLine("{0} ({1}) - {2}", p.Name, p.Company, p.Price);
            }
            //Console.ReadKey();

            Console.WriteLine("\n3.2 Join");
            using (PhoneContext db = new PhoneContext())
            {
                var result = from phone in db.Phones
                             join company in db.Companies on phone.CompanyId equals company.Id
                             join country in db.Countries on company.CountryId equals country.Id
                             select new
                             {
                                 Name = phone.Name,
                                 Company = company.Name,
                                 Price = phone.Price,
                                 Country = country.Name
                             };
                foreach (var p in result)
                    Console.WriteLine("{0} ({1}) - {2}, {3}", p.Name, p.Company, p.Price, p.Country);
            }
            Console.ReadKey();

            Console.WriteLine("\n4 Group");
            using (PhoneContext db = new PhoneContext())
            {
                var groups = from p in db.Phones
                             group p by p.Company.Name;
                foreach (var g in groups)
                {
                    Console.WriteLine(g.Key);
                    foreach (var p in g)
                        Console.WriteLine("{0} - {1}", p.Name, p.Price);
                    Console.WriteLine();
                }
            }
            //Console.ReadKey();

            Console.WriteLine("\n5 Union");
            using (PhoneContext db = new PhoneContext())
            {
                var phones = db.Phones.Where(p => p.Price < 25000)
                    .Union(db.Phones.Where(p => p.Name.Contains("Samsung")));
                foreach (var item in phones)
                    Console.WriteLine(item.Name);
            }
            //Console.ReadKey();

            Console.WriteLine("\n6 Intersect");
            using (PhoneContext db = new PhoneContext())
            {
                var phones = db.Phones.Where(p => p.Price < 25000)
                    .Intersect(db.Phones.Where(p => p.Name.Contains("Samsung")));
                foreach (var item in phones)
                    Console.WriteLine(item.Name);
            }
            //Console.ReadKey();

            Console.WriteLine("\n7 Except");
            using (PhoneContext db = new PhoneContext())
            {
                var selector1 = db.Phones.Where(p => p.Price < 25000); // Samsung Galaxy S4, Samsung Galaxy S4, iPhone S4
                var selector2 = db.Phones.Where(p => p.Name.Contains("Samsung")); // Samsung Galaxy S4, Samsung Galaxy S4
                var phones = selector1.Except(selector2); // результат -  iPhone S4

                foreach (var item in phones)
                    Console.WriteLine(item.Name);
            }
            Console.ReadKey();

            Console.WriteLine("\n8 Count");

            using (PhoneContext db = new PhoneContext())
            {
                int number1 = db.Phones.Count();
                // найдем кол-во моделей, которые в названии содержат Samsung
                int number2 = db.Phones.Count(p => p.Name.Contains("Samsung"));

                Console.WriteLine(number1);
                Console.WriteLine(number2);
            }

            //Console.ReadKey();

            Console.WriteLine("\n9 Min Max Aver");
            using (PhoneContext db = new PhoneContext())
            {
                // минимальная цена
                int minPrice = db.Phones.Min(p => p.Price);
                // максимальная цена
                int maxPrice = db.Phones.Max(p => p.Price);
                // средняя цена на телефоны фирмы Samsung
                double avgPrice = db.Phones.Where(p => p.Company.Name == "Samsung")
                                    .Average(p => p.Price);

                Console.WriteLine(minPrice);
                Console.WriteLine(maxPrice);
                Console.WriteLine(avgPrice);
            }
            //Console.ReadKey();

            Console.WriteLine("\n10 Sum");
            using (PhoneContext db = new PhoneContext())
            {
                // суммарная цена всех моделей
                int sum1 = db.Phones.Sum(p => p.Price);
                // суммарная цена всех моделей фирмы Samsung
                int sum2 = db.Phones.Where(p => p.Name.Contains("Samsung"))
                                    .Sum(p => p.Price);
                Console.WriteLine(sum1);
                Console.WriteLine(sum2);
            }
            Console.ReadKey();

            Console.WriteLine("\n11 AsNoTracking");
            using (PhoneContext db = new PhoneContext())
            {
                Company comp1 = db.Companies.FirstOrDefault(p => p.Id == 1);
                Company comp2 = db.Companies.FirstOrDefault(p => p.Id == 2);


                db.Phones.Add(new Phone { Name = "Samsung Galaxy Note", Company = comp1, Price = 20000 });
                db.Phones.Add(new Phone { Name = "iPhone 6", Company = comp2, Price = 20000 });
                db.SaveChanges();
                Phone firstPhone = db.Phones.AsNoTracking().FirstOrDefault();
                firstPhone.Name = "Samsung Galaxy Ace 2";
                db.SaveChanges();

                var phones = db.Phones.AsNoTracking().ToList();
                foreach (var item in phones)
                    Console.WriteLine("{0}, {1}", item.Name, item.CompanyId);
            }
            Console.ReadKey();

        }
    }

}

