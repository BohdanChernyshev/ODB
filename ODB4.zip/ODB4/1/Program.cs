﻿using System;
using System.Text;
using System.Data;
using System.Data.Linq;
using System.Linq;
using System.Data.Linq.Mapping;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;


namespace _1
{
    [Table(Name = "Driver")]
    public class Driver
    {
        [Column(Name = "Dr_id", IsPrimaryKey = true, IsDbGenerated = false)]
        public long Dr_id { get; set; }
        [Column(Name = "Dr_Name")]
        public string Dr_Name { get; set; }
        [Column(Name = "Spent_Days")]
        public int Spent_Days { get; set; }
        [Column(Name = "Is_Dr_Free")]
        public bool Is_Dr_Free { get; set; }
    }

    public class DriverDataContext : DataContext
    {
        public DriverDataContext(string connectionString)
            : base(connectionString)
        {

        }
        public Table<Driver> Drivers { get { return this.GetTable<Driver>(); } }

        [Function(Name = "FindDriversByName")]
        [return: Parameter(DbType = "Int")]
        public IEnumerable<Driver> FindDriversByName([Parameter(Name = "name", DbType = "NVarChar(100)")] string name)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), name);
            return ((IEnumerable<Driver>)(result.ReturnValue));
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = UTF8Encoding.UTF8;
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\DB\DB_6.mdf;Integrated Security=True;Connect Timeout=30";
            DataContext db = new DataContext(connectionString);


            //Виводить таблицю
            var query = from u in db.GetTable<Driver>()
                        select u;
            Console.WriteLine("Таблиця Driver:");
            foreach (var D in query)
            {
                Console.WriteLine("{0} \t{1} \t{2} \t{3}", D.Dr_id, D.Dr_Name, D.Spent_Days, D.Is_Dr_Free);
            }
            Console.ReadKey();
            Console.WriteLine();

            //Видаляє рядок
            var to_del = from u in db.GetTable<Driver>() where u.Dr_id == 3 select u;
            db.GetTable<Driver>().DeleteAllOnSubmit(to_del);
            db.SubmitChanges();
            Console.WriteLine("Об'єкт видалено");
            foreach (var D in db.GetTable<Driver>())
            {
                Console.WriteLine("{0} \t{1} \t{2} \t{3}", D.Dr_id, D.Dr_Name, D.Spent_Days, D.Is_Dr_Free);

            }

            //Додає рядок
            Driver Dr = new Driver {Dr_id=3, Dr_Name = "Ronald"};
            // добавляем его в таблицу Users
            db.GetTable<Driver>().InsertOnSubmit(Dr);
            db.SubmitChanges();
            Console.WriteLine();
            Console.WriteLine("Після додавання");
            foreach (var D in db.GetTable<Driver>().OrderByDescending(u => u.Dr_id).Take(5))
            {
                Console.WriteLine("{0} \t{1} \t{2} \t{3}", D.Dr_id, D.Dr_Name, D.Spent_Days, D.Is_Dr_Free);

            }
            Console.ReadKey();

            //Змінює рядки, повертає кількість змінених
            Console.WriteLine();
            int modifedRowsNumber = db.ExecuteCommand("UPDATE Driver \n SET Spent_Days=Spent_Days+1");
            Console.WriteLine("Затронуто рядків: {0}", modifedRowsNumber);
            db = new DataContext(connectionString);
            foreach (var D in db.GetTable<Driver>().OrderByDescending(u => u.Dr_id).Take(5))
            {
                Console.WriteLine("{0} \t{1} \t{2} \t{3}", D.Dr_id, D.Dr_Name, D.Spent_Days, D.Is_Dr_Free);

            }
            Console.ReadKey();
            Console.WriteLine();

            //Повертає результат запиту SELECT
            Console.WriteLine();
            IEnumerable<Driver> dres= db.ExecuteQuery<Driver>("SELECT * From Driver WHERE Dr_id = {0}", 3);
            Console.WriteLine("Результат SQL запиту: {0} ", dres);
            db = new DataContext(connectionString);
            foreach (var D in dres)
            {
                Console.WriteLine("{0} \t{1} \t{2} \t{3}", D.Dr_id, D.Dr_Name, D.Spent_Days, D.Is_Dr_Free);

            }
            Console.ReadKey();
            Console.WriteLine();

            //foreach (var D in db.GetTable<Driver>().OrderByDescending(u => u.Dr_id).Take(5))
            //{
            //    Console.WriteLine("{0} \t{1} \t{2} \t{3}", D.Dr_id, D.Dr_Name, D.Spent_Days, D.Is_Dr_Free);

            //}
            DriverDataContext db2 = new DriverDataContext(connectionString);
            string name = "n";
            dres=db2.FindDriversByName(name);
            Console.WriteLine("Пошук водіїв за ім'ям: {0}" , name);
            foreach (var D in dres)
            {
                Console.WriteLine("{0} \t{1} \t{2} \t{3}", D.Dr_id, D.Dr_Name, D.Spent_Days, D.Is_Dr_Free);

            }
            Console.ReadKey();
        }
    }    
}