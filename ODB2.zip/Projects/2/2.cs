﻿using System;
using System.Data.SqlClient;

namespace _2
{
    class Program
    {
        static void Main(string[] args)
        {

            SqlConnectionStringBuilder connect =
                new SqlConnectionStringBuilder();
            connect.InitialCatalog = "C:\\USERS\\USER\\DESKTOP\\DB\\DB_6.MDF";
            connect.DataSource = @"(localdb)\MSSQLLocalDB";
            connect.ConnectTimeout = 30;
            connect.IntegratedSecurity = true;

            // Создание открытого подключения
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = connect.ConnectionString;
                try
                {
                    
                    cn.Open();
                    Console.WriteLine("It worked");
                    string strSQL = "SELECT * FROM Driver";
                    SqlCommand myCommand = new SqlCommand(strSQL, cn);
                    SqlDataReader dr = myCommand.ExecuteReader();
                    while (dr.Read())
                    Console.WriteLine("ID: {0}  Name: {1}", dr[0], dr[1]);

                    Console.ReadKey();
                    Console.Clear();

                    cn.Close();
                    cn.Open();

                    strSQL = "UPDATE Driver SET Dr_Name = 'abgrtnh' WHERE Dr_id = 1";
                    myCommand = new SqlCommand(strSQL, cn);

                    Console.WriteLine("Changed: {0}", myCommand.ExecuteNonQuery());
                }
                catch (SqlException ex)
                {
                    // Протоколировать исключение
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    // Гарантировать освобождение подключения
                    Console.ReadKey();
                    cn.Close();
                }
            }
        }
    }
}

