﻿using System;
using System.Data.SqlClient;
using System.Data.Common;
using System.Configuration;


namespace ODB
{
    class Program
    {
        static void Main(string[] args)
        {

            // Получение строки подключения и поставщика из *.config
            string dp = ConfigurationManager.AppSettings["provider"];
            string cnStr = ConfigurationManager.AppSettings["cnStr"];

            // Получение генератора поставщика
            DbProviderFactory df = DbProviderFactories.GetFactory(dp);

            // Получение объекта подключения
            using (DbConnection cn = df.CreateConnection())
            {


                Console.WriteLine("Объект подключения --> " + cn.GetType().Name);
                cn.ConnectionString = cnStr;
                cn.Open();
                if (cn is SqlConnection)
                {
                    // Вывод используемой версии SQL Server
                    Console.WriteLine(((SqlConnection)cn).ServerVersion);
                }

                // Создание объекта команды
                DbCommand cmd = df.CreateCommand();
                Console.WriteLine("Объект команды --> " + cmd.GetType().Name);
                cmd.Connection = cn;
                cmd.CommandText = "Select * From Driver";

                // Вывод данных с помощью объекта чтения данных
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    Console.WriteLine("Объект чтения данных --> " + dr.GetType().Name);
                    Console.WriteLine("\n*** Текущее содержимое Inventory ***\n");
                    while (dr.Read())
                        Console.WriteLine("-> Driver #{0} - {1}\n",
                            dr["Dr_id"], dr["Dr_Name"].ToString());
                }
                Console.ReadLine();
            }

        }
    }
}
