﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace _3
{
    public class InventoryDAL
    {
        private SqlConnection connect = null;

        public void OpenConnection(string connectionString)
        {
            connect = new SqlConnection(connectionString);
            connect.Open();
        }

        public void CloseConnection()
        {
            connect.Close();
        }
       
        public void InsertAuto( long id, string name, int days, bool free)
            {
                // Оператор SQL
                string sql = string.Format("Insert Into Driver" +
                    "(Dr_id, Dr_Name, Spent_Days, Is_Dr_Free) Values('{0}','{1}','{2}','{3}')", id, name, days, free);

            //Параметризованная команда
            using (SqlCommand cmd = new SqlCommand(sql, this.connect))
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@Dr_id";
                param.Value = id;
                param.SqlDbType = SqlDbType.BigInt;
                cmd.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@Dr_Name";
                param.Value = name;
                param.SqlDbType = SqlDbType.NVarChar;
                param.Size = 300;
                cmd.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@Spent_Days";
                param.Value = days;
                param.SqlDbType = SqlDbType.Int;
                cmd.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@Is_Dr_Free";
                param.Value = free;
                param.SqlDbType = SqlDbType.Bit;
                cmd.Parameters.Add(param);

                cmd.ExecuteNonQuery();
            }



        }
        public void Delete( long id)
        {
            string sql = string.Format("Delete from Driver where Dr_id = '{0}'", id);
            using (SqlCommand cmd = new SqlCommand(sql, this.connect))
            {
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    Exception error = new Exception("Something wrong, I can feel it", ex);
                    throw error;
                }
            }
        }
        public void UpdateName(long id, string Name)
        {
            string sql = string.Format("Update Driver Set Dr_Name = '{0}' Where Dr_id = '{1}'",
                   Name, id);
            using (SqlCommand cmd = new SqlCommand(sql, this.connect))
            {
                cmd.ExecuteNonQuery();
            }
        }
        public DataTable GetAllDriversAsDataTable()
        {
            DataTable inv = new DataTable();
            string sql = "Select * From Driver";
            using (SqlCommand cmd = new SqlCommand(sql, this.connect))
            {
                SqlDataReader dr = cmd.ExecuteReader();
                inv.Load(dr);
                dr.Close();
            }
            Console.Write("\n");
            return inv;
        }
        public string LookDrName(long carId)
        {
            string carPetName = string.Empty;

            // Задание имени хранимой процедуры
            using (SqlCommand cmd = new SqlCommand("GetDrName", this.connect))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                // Входной параметр.
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@DRID";
                param.SqlDbType = SqlDbType.BigInt;
                param.Value = carId;

                //По умолчанию параметры считаются входными, но все же для ясности:
                param.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param);

                // Выходной параметр.
                param = new SqlParameter();
                param.ParameterName = "@Name";
                param.SqlDbType = SqlDbType.NVarChar;
                param.Size = 300;
                param.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(param);

                // Выполнение хранимой процедуры.
                cmd.ExecuteNonQuery();
                // Возврат выходного параметра.
                carPetName = ((string)cmd.Parameters["@Name"].Value).Trim();
            }
            return carPetName;
        }

        public void ResetDays(bool throwEx, long drid)
        {
            // Выборка имени по идентификатору клиента
            string Name = string.Empty;
            SqlCommand cmdSelect = new SqlCommand(string.Format("Select * from Driver where Dr_id = '{0}'", drid), connect);
            using (SqlDataReader dr = cmdSelect.ExecuteReader())
            {
                if (dr.HasRows)
                {
                    dr.Read();
                    Name = (string)dr["Dr_Name"];

                }
                else return;
            }

            // Создание объектов команд для каждого шага операции.
            SqlCommand cmdRemove = new SqlCommand(string.Format("Delete from Driver where Dr_id = {0}", drid), connect);
            SqlCommand cmdInsert = new SqlCommand(string.Format("Insert Into Driver" + "(Dr_id, Dr_name, Spent_Days, Is_Dr_Free) Values" + "({0}, '{1}', {2}, '{3}')", drid, Name, 0, true), connect);
            // Получаем из объекта подключения.
            SqlTransaction tx = null;
            try
            {
                tx = connect.BeginTransaction();
                // Включение команд в транзакцию
                cmdRemove.Transaction = tx;
                cmdInsert.Transaction = tx;
                // Выполнение команд.
                cmdRemove.ExecuteNonQuery();
                cmdInsert.ExecuteNonQuery();
                // Имитация ошибки.
                if (throwEx)
                {
                    throw new ApplicationException("Ошибка базы данных! Транзакция завершена провалом.");
                }
                // Фиксация.
                tx.Commit();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                // При возникновении любой ошибки выполняется откат транзакции.
                tx.Rollback();
            }

        }
    }
    class program
    {
        static public void DataRead(DataTable t)
        {
            foreach (DataRow item in t.Rows)
            {
                Console.WriteLine("Id : {0} \t Name : {1} \t Spent Days : {2} \t Is free : {3}", item[0], item[1], item[2], item[3]);
            }
        }
        static void Main(string[] arg)
        {
            InventoryDAL inv= new InventoryDAL();
            inv.OpenConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=C:\\USERS\\USER\\DESKTOP\\DB\\DB_6.MDF;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            inv.InsertAuto(1, "a",5, true);
            inv.InsertAuto(2, "b",4, false);
            DataTable t = inv.GetAllDriversAsDataTable();

            DataRead(t);
            Console.ReadKey();

            inv.UpdateName(2, "erznmhnfgasnyjs");
            t = inv.GetAllDriversAsDataTable();
            DataRead(t);
            Console.ReadKey();

            inv.Delete(1);
            t = inv.GetAllDriversAsDataTable();
            DataRead(t);
            Console.ReadKey();

            Console.WriteLine(inv.LookDrName(2));
            Console.ReadKey();

            
            inv.ResetDays(false, 2);
            t = inv.GetAllDriversAsDataTable();
            DataRead(t);
            Console.ReadKey();



            inv.Delete(2);
            inv.CloseConnection();
        }
    }
}
