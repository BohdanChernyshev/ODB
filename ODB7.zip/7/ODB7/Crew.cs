namespace ODB7
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Crew")]
    public partial class Crew
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Crew()
        {
            Voyage = new HashSet<Voyage>();
        }

        [Key]
        public int Cr_id { get; set; }

        public long Dr_1id { get; set; }

        [Required]
        [StringLength(30)]
        public string Tr_id_ { get; set; }

        public long? Dr_2id { get; set; }

        public virtual Driver Driver { get; set; }

        public virtual Driver Driver1 { get; set; }

        public virtual Truck Truck { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Voyage> Voyage { get; set; }
    }
}
