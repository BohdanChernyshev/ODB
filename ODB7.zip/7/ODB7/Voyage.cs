namespace ODB7
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Voyage")]
    public partial class Voyage
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Voyage()
        {
            Happened_Br = new HashSet<Happened_Br>();
        }

        [Key]
        public int Vo_id { get; set; }

        public int Cr_id_ { get; set; }

        [Required]
        [StringLength(200)]
        public string V_Beg { get; set; }

        [Required]
        [StringLength(200)]
        public string V_End { get; set; }

        [Column(TypeName = "date")]
        public DateTime B_Date { get; set; }

        [Column(TypeName = "date")]
        public DateTime E_Date { get; set; }

        public bool? Is_Completed { get; set; }

        [Required]
        [StringLength(200)]
        public string Cargo { get; set; }

        public virtual Crew Crew { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Happened_Br> Happened_Br { get; set; }
    }
}
