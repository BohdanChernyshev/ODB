namespace ODB7
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class BaseContext : DbContext
    {
        public BaseContext()
            : base("name=BaseContext")
        {
        }

        public virtual DbSet<Breakage> Breakage { get; set; }
        public virtual DbSet<Crew> Crew { get; set; }
        public virtual DbSet<Driver> Driver { get; set; }
        public virtual DbSet<Happened_Br> Happened_Br { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }
        public virtual DbSet<Truck> Truck { get; set; }
        public virtual DbSet<Voyage> Voyage { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Breakage>()
                .Property(e => e.Price)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Breakage>()
                .HasMany(e => e.Happened_Br)
                .WithRequired(e => e.Breakage)
                .HasForeignKey(e => e.Br_id_)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Crew>()
                .Property(e => e.Tr_id_)
                .IsUnicode(false);

            modelBuilder.Entity<Crew>()
                .HasMany(e => e.Voyage)
                .WithRequired(e => e.Crew)
                .HasForeignKey(e => e.Cr_id_)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Driver>()
                .HasMany(e => e.Crew)
                .WithRequired(e => e.Driver)
                .HasForeignKey(e => e.Dr_1id)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Driver>()
                .HasMany(e => e.Crew1)
                .WithOptional(e => e.Driver1)
                .HasForeignKey(e => e.Dr_2id);

            modelBuilder.Entity<Truck>()
                .Property(e => e.Tr_id)
                .IsUnicode(false);

            modelBuilder.Entity<Truck>()
                .HasMany(e => e.Crew)
                .WithRequired(e => e.Truck)
                .HasForeignKey(e => e.Tr_id_)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Voyage>()
                .HasMany(e => e.Happened_Br)
                .WithRequired(e => e.Voyage)
                .HasForeignKey(e => e.Vo_id_)
                .WillCascadeOnDelete(false);
        }
    }
}
