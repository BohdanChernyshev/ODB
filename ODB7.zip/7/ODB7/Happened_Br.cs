namespace ODB7
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Happened_Br
    {
        [Key]
        public int HB_id { get; set; }

        public int Vo_id_ { get; set; }

        public int Br_id_ { get; set; }

        public virtual Breakage Breakage { get; set; }

        public virtual Voyage Voyage { get; set; }
    }
}
