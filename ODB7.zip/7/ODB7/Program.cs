﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Data;

namespace ODB7
{
    //class DBContext : DbContext
    //{
    //    public DBContext() : base("name = BaseContext")
    //    { }
    //    public DbSet<Driver> Drivers { get; set; }
    //    public DbSet<Crew> Crews { get; set; }
    //    public DbSet<Happened_Br> Happened_Brs { get; set; }
    //    public DbSet<Truck> Trucks { get; set; }
    //    public DbSet<Voyage> Voyages { get; set; }
    //    public DbSet<Breakage> Breakages { get; set; }
    //}
    class Program
    {
        static void Main(string[] args)
        {

            

            using (BaseContext db = new BaseContext())
            {
                // добавление элементов
                db.Driver.Add(new Driver { Dr_Name = "Tom", Dr_id = 450, Spent_Days = 7, Is_Dr_Free = false });
                db.Driver.Add(new Driver { Dr_Name = "Not Tom", Dr_id = 5450, Spent_Days = 1, Is_Dr_Free = true });
                db.SaveChanges();
                // получение элементов
                var Dr = db.Driver;
                foreach (Driver u in Dr)
                    Console.WriteLine("{0}.{1} - {2}", u.Dr_Name, u.Dr_id, u.Spent_Days);
            }
            Console.Read();


        }
    }
 }
